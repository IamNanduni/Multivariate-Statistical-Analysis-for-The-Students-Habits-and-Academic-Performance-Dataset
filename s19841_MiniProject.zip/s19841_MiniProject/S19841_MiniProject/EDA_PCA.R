# Loading required libraries
library(dplyr)
library(ggplot2)
library(corrplot)
library(psych)
library(factoextra)
library(GPArotation)

# 1. Load dataset
data_loaded <- read.csv("C:/Users/Naduni/Desktop/s19841_MiniProject/student_habits_performance.csv", stringsAsFactors = TRUE)

# 2. Inspect data structure and summary
str(data_loaded)
summary(data_loaded)

# 3. Remove identifier
student_data <- data_loaded %>%dplyr::select(-student_id)
str(student_data)
summary(student_data)

# 4. Check for missing values
missing_values <- colSums(is.na(student_data))
print("Missing Values per Column:")
print(missing_values)

# 5. Handle outliers
# Select numeric columns
numeric_cols <- sapply(student_data, is.numeric)
numerical_student_data <- student_data[, numeric_cols]

# Function to remove rows with outliers using IQR method
remove_outliers <- function(df, column) {
  Q <- quantile(df[[column]], probs=c(0.25, 0.75), na.rm=TRUE)
  iqr <- IQR(df[[column]], na.rm=TRUE)
  lower_bound <- Q[1] - 1.5 * iqr
  upper_bound <- Q[2] + 1.5 * iqr
  df <- df[df[[column]] >= lower_bound & df[[column]] <= upper_bound, ]
  return(df)
}

boxplot(numerical_student_data)

# Remove outliers for each numeric variable
student_data_clean <- student_data
for (col in names(numerical_student_data)) {
  student_data_clean <- remove_outliers(student_data_clean, col)
}
print(paste("Rows removed due to outliers:", nrow(student_data) - nrow(student_data_clean)))

# Update numeric data after outlier removal
numerical_student_data_clean <- student_data_clean[, numeric_cols]


# Boxplots to verify outlier removal
pdf("boxplots_cleaned.pdf")
par(mfrow=c(3,3))
for (col in names(numerical_student_data_clean)) {
  boxplot(numerical_student_data_clean[[col]], main=paste("Boxplot of", col, "(Cleaned)"), col="lightgreen")
}
dev.off()

# 6. Data type conversion (verify factors)
student_data_clean$gender <- as.factor(student_data_clean$gender)
student_data_clean$part_time_job <- as.factor(student_data_clean$part_time_job)
student_data_clean$diet_quality <- as.factor(student_data_clean$diet_quality)
student_data_clean$parental_education_level <- as.factor(student_data_clean$parental_education_level)
student_data_clean$internet_quality <- as.factor(student_data_clean$internet_quality)
student_data_clean$extracurricular_participation <- as.factor(student_data_clean$extracurricular_participation)

# 7. Handle duplicates
duplicates <- sum(duplicated(student_data_clean))
print(paste("Number of duplicate rows:", duplicates))
student_data_unique <- unique(student_data_clean)
print(paste("Rows after removing duplicates:", nrow(student_data_unique)))

# 8. Data transformation for multivariate analysis
# Standardize numeric variables for PCA
numerical_student_data_std <- as.data.frame(scale(numerical_student_data_clean))

# Log transformation (adding 1 to handle zeros)
numerical_student_data_log <- as.data.frame(lapply(numerical_student_data_clean, function(x) log(x + 1)))
colnames(numerical_student_data_log) <- paste0(colnames(numerical_student_data_clean), "_log")

# Combine categorical and standardized numeric data
analysis_data <- bind_cols(student_data_unique %>% select_if(is.factor), numerical_student_data_std)
str(analysis_data)

# EDA Visualizations
# Histograms for numeric variables
pdf("histograms_cleaned.pdf")
par(mfrow=c(3,3))
for (col in names(numerical_student_data_clean)) {
  hist(numerical_student_data_clean[[col]], main=paste("Histogram of", col), xlab=col, col="lightblue")
}
dev.off()

# Correlation matrix
pdf("correlation_matrix.pdf")
cor_matrix <- cor(numerical_student_data_std, use="complete.obs")
corrplot(cor_matrix, method="circle", type="upper", tl.col="black", tl.srt=45)
dev.off()

# Bar plots for categorical variables
pdf("categorical_barplots.pdf")
par(mfrow=c(3,2))
categorical_vars <- names(student_data_unique %>% select_if(is.factor))
for (cat_var in categorical_vars) {
  barplot(table(student_data_unique[[cat_var]]), main=paste("Bar Plot of", cat_var), col="lightcoral", las=2)
}
dev.off()

# Scatter plot: study_hours_per_day vs exam_score
ggplot(student_data_unique, aes(x=study_hours_per_day, y=exam_score)) +
  geom_point() +
  geom_smooth(method="lm", col="blue") +
  theme_minimal() +
  labs(title="Study Hours vs Exam Score (Cleaned)", x="Study Hours per Day", y="Exam Score")
ggsave("scatter_study_exam.pdf")

# Boxplot: exam_score by diet_quality
ggplot(student_data_unique, aes(x=diet_quality, y=exam_score, fill=diet_quality)) +
  geom_boxplot() +
  theme_minimal() +
  labs(title="Exam Score by Diet Quality (Cleaned)", x="Diet Quality", y="Exam Score")
ggsave("boxplot_diet_exam.pdf")

# 9. PCA
PCA_Result <- prcomp(numerical_student_data_std, scale=TRUE)
summary(PCA_Result)

# Save scree plot
fviz_eig(PCA_Result, addlabels=TRUE, ylim=c(0,20))
ggsave("scree_plot.pdf")

# Biplot of individuals and variables
fviz_pca_biplot(PCA_Result, col.var="#2E9FDF", col.ind="#696969", repel=TRUE)
ggsave("pca_biplot.pdf")

# Variance explained
VE <- PCA_Result$sdev^2
PVE <- VE/sum(VE)
print("Proportion of Variance Explained:")
print(round(PVE, 3))

