# Load required libraries
library(tidyverse)
library(CCA)
library(psych)
library(factoextra)
library(corrplot)
library(e1071) # For skewness check


# Define continuous variables
continuous_vars <- c("age", "study_hours_per_day", "social_media_hours", "netflix_hours", 
                     "attendance_percentage", "sleep_hours", "exercise_frequency", 
                     "mental_health_rating", "exam_score")




# Define variable sets for CCA
lifestyle_vars <- c("social_media_hours", "netflix_hours", "sleep_hours", 
                    "exercise_frequency", "mental_health_rating")
academic_vars <- c("study_hours_per_day", "attendance_percentage", "exam_score")

# CCA
cca_result <- cc(numerical_student_data_std[, lifestyle_vars], numerical_student_data_std[, academic_vars])

# Summary of canonical correlations
print("Canonical Correlations:")
print(cca_result$cor)

# Canonical loadings
print("Canonical Loadings (Lifestyle Set):")
print(cca_result$xcoef)
print("Canonical Loadings (Academic Set):")
print(cca_result$ycoef)

# Wilks' Lambda test
library(CCP)
wilks_test <- p.asym(cca_result$cor, nrow(numerical_student_data_std), length(lifestyle_vars), length(academic_vars))
print("Wilks' Lambda Test:")
print(wilks_test)

# Plot canonical variates
png("cca_plot.png", width = 600, height = 600)
plot(cca_result$scores$xscores[,1], cca_result$scores$yscores[,1], 
     xlab = "Lifestyle Canonical Variate 1", ylab = "Academic Canonical Variate 1", 
     main = "First Canonical Variate Pair", pch = 19, col = "blue")
abline(lm(cca_result$scores$yscores[,1] ~ cca_result$scores$xscores[,1]), col = "red")
dev.off()