# Loading required libraries
library(MASS)  # For LDA
library(ggplot2)  # For visualization
library(caret)  # For confusion matrix and cross-validation

# Assuming numerical_student_data_std is already standardized
# Create a categorical outcome based on exam_score (above vs. below median)
data <- as.data.frame(numerical_student_data_std)
data$High_Performance <- ifelse(data$exam_score > median(data$exam_score), "High", "Low")
data$High_Performance <- as.factor(data$High_Performance)

# Check for missing values
if (any(is.na(data))) {
  data <- na.omit(data)
}

# Select predictors (exclude exam_score since it's used for the outcome)
predictors <- c("age", "study_hours_per_day", "social_media_hours", "netflix_hours",
                "attendance_percentage", "sleep_hours", "exercise_frequency", 
                "mental_health_rating")
da_data <- data[, c(predictors, "High_Performance")]

# Check assumptions: Normality (approximate) and equal covariance
# Normality check (visual, using Q-Q plots for key predictors)
par(mfrow = c(2, 2))
for (var in predictors[1:4]) {
  qqnorm(data[[var]], main = paste("Q-Q Plot for", var))
  qqline(data[[var]], col = "red")
}
par(mfrow = c(1, 1))

# Equal covariance check (Box's M test, approximate via covariance matrices)
cov_high <- cov(da_data[da_data$High_Performance == "High", predictors])
cov_low <- cov(da_data[da_data$High_Performance == "Low", predictors])
print("Covariance Matrix (High Performance):")
print(cov_high)
print("Covariance Matrix (Low Performance):")
print(cov_low)

# Perform Linear Discriminant Analysis
lda_model <- lda(High_Performance ~ ., data = da_data)
print("LDA Results:")
print(lda_model)

# Extract discriminant function coefficients
lda_coefficients <- lda_model$scaling
print("Discriminant Function Coefficients:")
print(lda_coefficients)

# Group means on discriminant function
lda_means <- lda_model$means
print("Group Means on Predictors:")
print(lda_means)

# Predict and evaluate classification accuracy
lda_pred <- predict(lda_model, da_data)
confusion_matrix <- table(Predicted = lda_pred$class, Actual = da_data$High_Performance)
print("Confusion Matrix:")
print(confusion_matrix)

# Classification accuracy
accuracy <- mean(lda_pred$class == da_data$High_Performance)
print("Classification Accuracy:")
print(accuracy)

# Cross-validation (leave-one-out)
lda_cv <- lda(High_Performance ~ ., data = da_data, CV = TRUE)
cv_accuracy <- mean(lda_cv$class == da_data$High_Performance)
print("Cross-Validated Accuracy:")
print(cv_accuracy)

# Visualize discriminant scores
lda_scores <- as.data.frame(lda_pred$x)
lda_scores$High_Performance <- da_data$High_Performance
ggplot(lda_scores, aes(x = LD1, fill = High_Performance)) +
  geom_histogram(bins = 30, alpha = 0.5, position = "identity") +
  labs(title = "Histogram of LD1 Scores by Performance Group", x = "LD1 Score", y = "Count") +
  theme_minimal()

# Save results

print("LDA Results:")
print(lda_model)
print("Discriminant Function Coefficients:")
print(lda_coefficients)
print("Group Means on Predictors:")
print(lda_means)
print("Confusion Matrix:")
print(confusion_matrix)
print("Classification Accuracy:")
print(accuracy)
print("Cross-Validated Accuracy:")
print(cv_accuracy)
