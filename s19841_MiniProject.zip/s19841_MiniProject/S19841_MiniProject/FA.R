# Loading required libraries
library(psych)
library(corrplot)

# Correlation matrix visualization
corr_matrix <- cor(numerical_student_data_std)
corrplot(corr_matrix, method = "color", type = "upper", order = "hclust", 
         tl.col = "black", tl.srt = 45, addCoef.col = "black")

# Parallel analysis
fa.parallel(numerical_student_data_std, fa = "fa", fm = "ml")

# Factor analysis with 2 factors
fa_result <- fa(numerical_student_data_std, nfactors = 2, rotate = "oblimin", fm = "ml")
print("Factor Analysis Results:")
print(fa_result$loadings, cutoff = 0.3)
print("Variance Explained:")
print(fa_result$Vaccounted)
fa.diagram(fa_result, main = "Factor Analysis Diagram")

# PCA as an alternative
pca_result <- principal(numerical_student_data_std, nfactors = 2, rotate = "oblimin")
print("PCA Results:")
print(pca_result$loadings, cutoff = 0.3)
print("Variance Explained (PCA):")
print(pca_result$Vaccounted)

# Saving results

print("Correlation Matrix:")
print(corr_matrix)
print("Factor Analysis Results:")
print(fa_result)
print("PCA Results:")
print(pca_result)
